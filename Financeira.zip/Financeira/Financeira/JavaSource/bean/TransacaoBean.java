package bean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.ejb.EJB;
import javax.enterprise.context.RequestScoped;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.inject.Named;

import org.omnifaces.util.Messages;

import entidade.Transacao;
import servico.ServicoCartao;
import servico.ServicoCliente;
import servico.ServicoTransacao;

@Named
@RequestScoped
public class TransacaoBean implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 20444711951985271L;
	
	private Transacao transacao;
	
	private List<String> operacao;
	
	private String cvv;
	
	private String cartaoCredito;

	@EJB
	private ServicoTransacao servicoTransacao;
	
	@EJB
	private ServicoCartao servicoCartao;
	
	@EJB
	private ServicoCliente servicoCliente;
	
	public TransacaoBean() {
		this.transacao = new Transacao();
		this.setOperacao(new ArrayList<String>());
		this.getOperacao().add("Crédito");
		this.getOperacao().add("Débito");
		
	}
	
	public void cadastrarTransacao() {
		
		try {
			this.servicoTransacao.cadastrar(this.transacao, this.cartaoCredito, this.cvv);
			Messages.create("Transação efetuada com sucesso").add();
		}catch (Exception e){
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR,
					e.getMessage(), null);
			FacesContext context = FacesContext.getCurrentInstance();
			context.addMessage(null, message);
		}
		
	}
	
	public List<Transacao> listarTransacao(){
		return this.servicoTransacao.listarTransacao();
	}

	public Transacao getTransacao() {
		return transacao;
	}

	public void setTransacao(Transacao transacao) {
		this.transacao = transacao;
	}

	public List<String> getOperacao() {
		return operacao;
	}

	public void setOperacao(List<String> operacao) {
		this.operacao = operacao;
	}

	public String getCartaoCredito() {
		return cartaoCredito;
	}

	public void setCartaoCredito(String cartaoCredito) {
		this.cartaoCredito = cartaoCredito.replace(".", "");
	}

	public String getCvv() {
		return cvv;
	}

	public void setCvv(String cvv) {
		this.cvv = cvv;
	}
	
}
