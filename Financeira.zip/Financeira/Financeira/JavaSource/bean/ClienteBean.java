package bean;

import java.io.Serializable;
import java.util.List;
import javax.ejb.EJB;
import javax.enterprise.context.RequestScoped;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.inject.Named;

import org.omnifaces.util.Messages;

import entidade.Cliente;
import servico.ServicoCliente;


@Named
@RequestScoped
public class ClienteBean implements Serializable {

	private static final long serialVersionUID = 2549645775521572226L;

	private Cliente cliente;
	
	
	
	@EJB
	private ServicoCliente servicoCliente;
	
	public ClienteBean() {
		this.cliente = new Cliente();
		
	}
	
	
	
	public void cadastrarCliente(){
		
		try{
		
			this.servicoCliente.cadastrar(this.cliente);
		
			Messages.create("Cliente cadastrado com sucesso").add();
		}catch(Exception e){
			Messages.create(e.getMessage()).warn().add();
		}
	}

	public void removerCliente(Cliente cliente){
		
		try{
			this.servicoCliente.remover(cliente);
			Messages.create("Cliente removido com sucesso").add();
		}catch(Exception e){
			
			FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR,
					"Cliente possui cartões de crédito!", null);
			FacesContext context = FacesContext.getCurrentInstance();
			context.addMessage(null, message);
		}
	}
	
	public List<Cliente> listarClientes(){
		
		return this.servicoCliente.listarTodos();
	}

	
	public Cliente getCliente() {
		return cliente;
	}

	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}
}
