package bean;

import java.io.Serializable;
import java.util.List;

import javax.ejb.EJB;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;

import org.omnifaces.util.Messages;

import entidade.CartaoCredito;
import entidade.Cliente;
import servico.ServicoCartao;
import servico.ServicoCliente;

@Named
@RequestScoped
public class CartaoBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8523386292919799353L;

	private CartaoCredito cartao;
	
	
	
	@EJB
	private ServicoCartao servicoCartao;
	@EJB
	private ServicoCliente servicoCliente;
	
	public CartaoBean(){
		this.cartao = new CartaoCredito();
	}
	
	public void cadastrarCartao(){
		this.servicoCartao.cadastrar(this.cartao);
		Messages.create("Cartão cadastrado com sucesso").add();
	}
	
	public void removerCartao(){
		
		this.servicoCartao.remover(cartao);
		Messages.create("Cartão removido com sucesso").add();
	}
	
	public List<CartaoCredito> listarCartao(){
		
		return this.servicoCartao.listarTodos();
	}
	
	public List<Cliente> listarClientes(){
		
		return this.servicoCliente.listarTodos();
	}
	
		
	public CartaoCredito getCartao() {
		return cartao;
	}

	public void setCartao(CartaoCredito cartao) {
		this.cartao = cartao;
	}
	
}
