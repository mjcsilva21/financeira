package servico;

import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.validation.ConstraintViolationException;

import entidade.Cliente;

@Stateless
public class ServicoCliente {

	@PersistenceContext
	private EntityManager entityManager;
	
	public Cliente cadastrar(Cliente cliente) throws Exception {
		Cliente existente = this.buscarClientePorCpf(cliente.getCpf());
		if(existente == null){
		this.entityManager.persist(cliente);
		return cliente;
		}else{
			throw new Exception ("Cpf já existente!");
		}
	} 
	
	public Cliente remover(Cliente cliente) throws Exception{
		try{
		this.entityManager.remove(this.entityManager.merge(cliente));
		return cliente;
		}catch (ConstraintViolationException nre){
			throw new Exception ("Cliente possui cartões de crédito!");
			
		}
	}
	
	
	public List<Cliente> listarTodos(){
		
		return this.entityManager
				.createQuery("FROM Cliente c", Cliente.class)
				.getResultList();
	} 
	 
	public Cliente buscarPorId(String id){
		 return (Cliente) this.entityManager
				 .createQuery("FROM Cliente c WHERE c.id = :cid")
				 .setParameter("cid", id)
				 .getSingleResult();
	 }
	 
	public Cliente buscarClientePorCpf(String cpf){
		try{
		return (Cliente)  this.entityManager
				.createQuery("FROM Cliente c WHERE c.cpf= :p1")
				.setParameter("p1", cpf)
				.getSingleResult();
		}catch (NoResultException nre){
			return null;
		}
	}
	 
}
