package servico;


import java.text.DecimalFormat;
import java.util.List;
import java.util.Random;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import entidade.CartaoCredito;



@Stateless
public class ServicoCartao {

	@PersistenceContext
	private EntityManager entityManager;
	
		
	public CartaoCredito cadastrar(CartaoCredito cartao){
		cartao.setNumeroCartao(this.gerarNumeroCartao());
		cartao.setCodigoSeguranca(this.gerarCodigoSeguranca());
		
		this.entityManager.persist(cartao);
		return cartao;
	} 
	
	public void remover(CartaoCredito cartao){
		this.entityManager.remove(this.entityManager.merge(cartao));
	}
	
	 @SuppressWarnings("unchecked")
		public List<CartaoCredito> listarTodos(){
			
			Query query = this.entityManager.createQuery("FROM CartaoCredito carc");
			return query.getResultList();
			
		}
	 
	 private String gerarNumeroCartao(){
		 Random random = new Random();
		 DecimalFormat quatroDigitos = new DecimalFormat("0000");
		 String numeroCartao = "";
		 for (int i = 0; i < 4; i++){
			 numeroCartao += quatroDigitos.format(random.nextInt(9999));
		 }
		 
		 if (this.buscarCartaoPorNumero(numeroCartao)!=null){
			 numeroCartao = gerarNumeroCartao();
		 }
		 return numeroCartao;
	 
	 }
	 
	 private String gerarCodigoSeguranca(){
		 Random random = new Random();
		 DecimalFormat tresDigitos = new DecimalFormat("000");
		 String codigoSeguranca = "";
		 codigoSeguranca += tresDigitos.format(random.nextInt(999));
		 
		 return codigoSeguranca;
	 
	 }
	 
	 public CartaoCredito buscarCartaoPorNumero (String numeroCartao){
		 try{
				return (CartaoCredito)  this.entityManager
						.createQuery("FROM CartaoCredito c WHERE c.numeroCartao = :p1")
						.setParameter("p1", numeroCartao)
						.getSingleResult();
				}catch (NoResultException nre){
					return null;
				}
	 }
	 
}
