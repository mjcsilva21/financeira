package servico;

import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import entidade.CartaoCredito;
import entidade.Transacao;

@Stateless
public class ServicoTransacao {
	
	@EJB
	private ServicoCartao servicoCartao;
	
	@PersistenceContext
	private EntityManager entityManager;
	
	
	public Transacao cadastrar(Transacao transacao, String numeroCartao, String cvv) throws Exception {
		
		
		
		CartaoCredito cartao = this.servicoCartao.buscarCartaoPorNumero(numeroCartao);
		if(cartao == null)
			throw new Exception ("Cartão de crédito inexistente!");
		
		
		Double valor = transacao.getValorTransacao();
		
		if (transacao.getTipoOperacao().equals("Débito"))
			valor *= -1;
		
		valor = cartao.getLimite() + valor;
		//se o cartão não tiver limite
		if (valor < 0)
			throw new Exception("Cartão não possui limite para a transação!");
		
		cartao.setLimite(valor);
		transacao.setCartaoCredito(cartao);
		this.entityManager.persist(transacao);
		this.entityManager.persist(cartao);
		return transacao;
	}
	
	@SuppressWarnings("unchecked")
	public List<Transacao> listarTransacao(){
		Query query = this.entityManager.createQuery("FROM Transacao trans");
		return query.getResultList();
	}

}
